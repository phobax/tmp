var express = require('express'),
	fs = require("fs"),
  io = require('socket.io'),
	zlib = require('zlib'),
  path = require('path'),
  https = require('https'),
  bodyParser = require('body-parser');



class Server {

  constructor (port, https_routes, ws_callbacks) {

    this.port = port;
    this.app = express();
    this.app.use (bodyParser.urlencoded({ extended: true }));
    this.app.use (bodyParser.json());

    this.server = https.createServer ({key:fs.readFileSync("key.pem"), cert:fs.readFileSync("cert.pem"), passphrase : "test"}, this.app);
    this.ioserver = new io.listen (this.server);
  }

  init() {

  }

  start() {
    this.init();
    this.server.listen (this.port);
  }
}

module.exports.Server = Server;
/*
	ioserver.on("connection", socket=> {
		console.log("CON");
		socket.on("update_pod_state", data=>{
	    pod.update_state(data);
	  })

		socket.on("update_user_state", data=>{
			if (!user.connected) {
				user.connect();
			}
	    user.update_state(data);
	  })

		socket.on("user_request_order0", data=>{
			if (!user.connected) return;
			user.requestOrder([52.404305, 13.074146]);
		})

		socket.on("user_request_order1", data=>{
			if (!user.connected) return;
			user.requestOrder([52.397452, 13.058045]);
		})

		socket.on("user_confirm_order", data=>{
			if (!user.connected) return;

		})

		socket.on("user_start", data=>{
			if (!user.connected) return;

		})

		socket.on("user_pause", data=>{
			if (!user.connected) return;

		})

		socket.on("user_continue", data=>{
			if (!user.connected) return;

		})

		socket.on("user_end", data=>{
			if (!user.connected) return;

		})

		socket.on("user_cancel", data=>{
			if (!user.connected) return;
			user.cancel();
		})
	})

	setInterval(()=>{
		ioserver.emit("attach_order", pod.order);
	}, 500);
}
serverStart();
*/

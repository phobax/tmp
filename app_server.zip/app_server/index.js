var PORT = 8002

var express = require('express'),
	fs = require("fs"),
	app = express(),
	server = require('https').createServer({key:fs.readFileSync("key.pem"), cert:fs.readFileSync("cert.pem"), passphrase : "test"}, app),
	io = require('socket.io').listen(server),
	zlib = require('zlib'),
  path = require('path'),
	cors = require('cors');



server.listen(PORT);
console.log('Server listening on port '+PORT);

app.use(cors());
app.use(express.static(path.join(__dirname, '/public')));
